-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 17, 2019 at 04:57 PM
-- Server version: 10.1.37-MariaDB
-- PHP Version: 7.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `mobil`
--

-- --------------------------------------------------------

--
-- Table structure for table `daftar_mobil`
--

CREATE TABLE `daftar_mobil` (
  `id` int(11) NOT NULL,
  `Merk` varchar(30) NOT NULL,
  `Tahun Produksi` char(15) NOT NULL,
  `Pendiri` varchar(40) NOT NULL,
  `Harga` varchar(10) NOT NULL,
  `Gambar` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `daftar_mobil`
--

INSERT INTO `daftar_mobil` (`id`, `Merk`, `Tahun Produksi`, `Pendiri`, `Harga`, `Gambar`) VALUES
(1, 'Lamborghini', '1963', 'Ferruccio Lamborghini', 'US$97.5 JT', 'lambor2.jpg'),
(2, 'BMW', '2004 - 2005', 'Franz Josef Popp', '$76,84 ', 'bmw1.jpg'),
(3, 'Ferrari', '1947', 'Enzo Ferrari', '$1,921', 'ferr.jpg'),
(4, 'Chevrolet', '1911', 'Louis Chevrolet', '$65,900', 'chev.jpg'),
(5, 'Bugatti Automobiles SAS', '1909', 'Ettore Bugatti', '$1,700,000', 'bugatti.jpg'),
(6, 'Pagani', '1992', 'Horacio Pagani', '$741,000', 'pagani1.jpg'),
(7, 'Koenigsegg', '1994', 'Christian von Koenigsegg', '$600,910', 'gils.jpg'),
(8, 'Porsche', '1931', 'Ferdinand Porsche', '$484,000', 'por.jpg'),
(9, 'Mercedes-Benz', '1886', 'Karl Benz', '$455,500', 'marc.jpeg'),
(10, 'Maybach', '1909', 'Wilhelm Maybach', '$385,250', 'may.png');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `daftar_mobil`
--
ALTER TABLE `daftar_mobil`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `daftar_mobil`
--
ALTER TABLE `daftar_mobil`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
