<?php 
	$perusahaanMobil = [
			     [	
			     	"No"	=> "1",
			     	"Gambar" 							=> "lambor2.jpg",
			     	"Merk" 			=> "Lamborghini",
			     	"Tahun_produksi" 					=> "1963",
			     	"Pendiri" 						=> "Ferruccio Lamborghini",
			     	"Harga"					=> "US$ 97.5 JT",
			     	
			     ],

			     [	
			     	"No"	=> "2",
			     	"Gambar" 							=> "bmw1.jpg",
			     	"Merk" 			=> "BMW",
			     	"Tahun_produksi" 					=> "2004 - 2005",
			     	"Pendiri" 						=> "Franz Josef Popp",
			     	"Harga"					=> "€76,84 M",
			     	
			     ],

			     [	
			     	"No"	=> "3",
			     	"Gambar" 							=> "ferr.jpg",
			     	"Merk" 			=> "Ferrari",
			     	"Tahun_produksi" 					=> "1947",
			     	"Pendiri" 						=> "Enzo Ferrari",
			     	"Harga"					=> " €1,921M",
			     	
			     ],

			     [	
			     	"No"	=> "4",
			     	"Gambar" 							=> "chev.jpg",
			     	"Merk" 			=> "Chevrolet",
			     	"Tahun_produksi" 					=> "1911",
			     	"Pendiri" 						=> "Louis Chevrolet",
			     	"Harga"					=> "$65,900†",
			     	
			     ],

			     [	
			     	"No"	=> "5",
			     	"Gambar" 							=> "bugatti.jpg",
			     	"Merk" 			=> "Bugatti Automobiles SAS",
			     	"Tahun_produksi" 					=> "1909",
			     	"Pendiri" 						=> "Ettore Bugatti",
			     	"Harga"					=> "$1,700,000",
			     	
			     ],

			     [	
			     	"No"	=> "6",
			     	"Gambar" 							=> "pagani1.jpg",
			     	"Merk" 			=> "Pagani",
			     	"Tahun_produksi" 					=> "1992",
			     	"Pendiri" 						=> "Horacio Pagani",
			     	"Harga"					=> "$741,000 ",
			     	
			     ],

			     [	
			     	"No"	=> "7",
			     	"Gambar" 							=> "gils.jpg",
			     	"Merk" 			=> "Koenigsegg",
			     	"Tahun_produksi" 					=> "1994",
			     	"Pendiri" 						=> "Christian von Koenigsegg",
			     	"Harga"					=> "$600,910 ",
			     	
			     ],

			     [	
			     	"No"	=> "8",
			     	"Gambar" 							=> "por.jpg",
			     	"Merk" 			=> "Porsche",
			     	"Tahun_produksi" 					=> "1931",
			     	"Pendiri" 						=> "Ferdinand Porsche",
			     	"Harga"					=> "$484,000",
			     	
			     ],

			     [	
			     	"No"	=> "9",
			     	"Gambar" 							=> "marc.jpeg",
			     	"Merk" 			=> "Mercedes-Benz",
			     	"Tahun_produksi" 					=> "1886",
			     	"Pendiri" 						=> "Karl Benz",
			     	"Harga"					=> "$455,500",
			     	
			     ],

			     [	
			     	"No"	=> "10",
			     	"Gambar" 							=> "may.png",
			     	"Merk" 			=> "Maybach",
			     	"Tahun_produksi" 					=> "1909",
			     	"Pendiri" 						=> "Wilhelm Maybach",
			     	"Harga"					=> "$385,250",
			     	
			     ]

			 ];
 ?>

<!DOCTYPE html>
<html>
<head>
	<title>Latihan 5b</title>
</head>
<body>

<ul>
<?php foreach ($perusahaanMobil as $mhs): ?>
	<li>
		<a href="Latihan5c.php?No=<?= $mhs['No']; ?>&Gambar=<?= $mhs['Gambar']; ?>&Merk=<?= $mhs['Merk']; ?>&Tahun_produksi=<?= $mhs['Tahun_produksi']; ?>&Pendiri=<?= $mhs['Pendiri']; ?>&Harga=<?= $mhs['Harga']; ?>"><?= $mhs['No']; ?></a>
	</li>
<?php endforeach; ?>
</ul>

</body>
</html>