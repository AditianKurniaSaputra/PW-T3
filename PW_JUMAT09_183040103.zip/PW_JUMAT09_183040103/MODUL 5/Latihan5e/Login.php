<?php 
// cek apakah tombol submit sudah tekan atau belum 
if ( isset($_POST["submit"])) {
	// cek username dan password
	if ( $_POST["username"] == "admin" && $_POST["password"] == "admin11") {
		//  jika benar, redict ke halaman admin
		header("Location: admin.php");
		exit;
	} else {
		echo "username/password salah!"; 
	}
}

?>

<!DOCTYPE html>
<html>
<head>
	<title>Login</title>
	<style type="text/css">
		img{
			width: 100px;
			height: 100px;
			border-radius: 50%
		}
		div{
			border: 1px solid white;
			width: 300px;
			height: 350px;
			background-color: #A9A9A9;
			margin: 20px auto;
		}
	</style>
</head>
<body>
	<div>
		<h1 align="center"><em>Login Admin</em></h1>
		<center><img src="1.jpg"></center>

		<br>
		<form action="" method="post" align="center">
			<table align="center">
				<tr>
					<td>
						<label for="username"><em>Username </em></label>
					</td>
					<td>:</td>
					<td>
						<input type="text" name="username" id="username">
					</td>
				</tr>
				<tr>
					<td>
						<label for="password"><em>Password </em></label>
					</td>
					<td>:</td>
					<td>
						<input type="password" name="password" id="password">
					</td>
				</tr>
				<tr>
					<td>
						<button type="submit" name="submit">Login</button>
					</td>
					<td></td>
					<td></td>
				</tr>
			</table>
		</form>

	</div>


</body>
</html>