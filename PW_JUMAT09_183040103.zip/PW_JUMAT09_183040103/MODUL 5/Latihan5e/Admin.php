<!DOCTYPE html>
<html>
<head>
	<title>Halaman Admin</title>
</head>
<body>

	
		<h1><em>Selamat datang Admin</em></h1>

		<button><a href="login.php">Logout</a></button>
	
	
</body>
</html>