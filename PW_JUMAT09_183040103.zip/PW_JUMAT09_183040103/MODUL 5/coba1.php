<!DOCTYPE html>
<html>
<head>
	<title>Contoh Request Post</title>
</head>
<body>
	<form action="coba1.php" method="Post">
		<label for="nama">Nama anda</label>
		<input type="text" name="nama" id="nama">
		<br>
		<button type="submit" nama="submit">Kirim</button>
	</form>

	<br>

	<?php $namaanda = $_POST["nama"] ?>

	<h2>WELCOME TO THE JUNGLE,	<?php echo $namaanda; ?></h2>
</body>
</html>