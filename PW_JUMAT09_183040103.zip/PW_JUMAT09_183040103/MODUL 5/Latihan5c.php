<?php 
// cek apakah tidak ada data di $_GET
if(	!isset($_GET["No"])) {
	// redirect
	header("Location: Latihan5b.php");
	exit;
}
?>



<!DOCTYPE html>
<html>
<head>
	<title>Perusahaan Mobil</title>
</head>
<body>
	<table border="1" cellspacing="0" cellpadding="3">
		<tr align="center">
			<td>No</td>
			<td>Gambar</td>
			<td width="110">Merk</td>
			<td width="110">Tahun produksi</td>
			<td>Pendiri</td>
			<td width="135">Harga</td>
			
		</tr>
		<tr>
			<td align="center"><?= $_GET["No"] ?></td>
			<td align="center"><img src="img/<?= $_GET["Gambar"]; ?>"></td>
			<td><?= $_GET["Merk"] ?></td>
			<td><?= $_GET["Tahun_produksi"] ?></td>
			<td><?= $_GET["Pendiri"] ?></td>
			<td><?= $_GET["Harga"] ?></td>
			
		</tr>
	</table>


<a href="Latihan5b.php">kembali</a>
</body>
</html>