<?php 
// koneksi ke database
$conn = mysqli_connect("localhost", "root", "", "mobil");


function query($query) {
	global $conn;
	$result = mysqli_query($conn, $query);
	$rows = [];
	while( $row = mysqli_fetch_assoc($result) ) {
		$rows[] = $row;
	}
	return $rows;
}


function tambah($data) {
	global $conn;

	$Gambar = htmlspecialchars($data["Gambar"]);
	$Merk = htmlspecialchars($data["Merk"]);
	$TahunProduksi = htmlspecialchars($data["Tahun Produksi"]);
	$Pendiri = htmlspecialchars($data["Pendiri"]);
	$Harga = htmlspecialchars($data["Harga"]);
	

	$query = "INSERT INTO daftar_mobil
				VALUES
			  ($Gambar', '$Merk', '$Tahun Produksi', '$Pendiri', '$Harga')
			";

	//die($query);
	mysqli_query($conn, $query);

	return mysqli_affected_rows($conn);
}


function hapus($id) {
	global $conn;
	mysqli_query($conn, "DELETE FROM daftar_mobil WHERE id = $id");
	return mysqli_affected_rows($conn);
}


function ubah($data) {
	global $conn;

	$id = $data["id"];
	$Gambar = htmlspecialchars($data["Gambar"]);
	$Merk = htmlspecialchars($data["Merk"]);
	$TahunProduksi = htmlspecialchars($data["Tahun Produksi"]);
	$Pendiri = htmlspecialchars($data["Pendiri"]);
	$Harga = htmlspecialchars($data["Harga"]);
	
	$query = "UPDATE daftar_mobil SET
				Gambar = '$Gambar',
				Merk = '$Merk',
				TahunProduksi = '$Tahun Produksi',
				Pendiri = '$Pendiri',
				Harga = '$Harga'
			  WHERE id = $id
			";

	mysqli_query($conn, $query);

	return mysqli_affected_rows($conn);	
}

function cari($keyword) {
	$query = "SELECT * FROM daftar_mobil
				WHERE
			  Merk LIKE '%$keyword%' OR
			  TahunProduksi LIKE '%$keyword%' OR
			  Pendiri LIKE '%$keyword%' OR
			  Harga LIKE '%$keyword%' OR
			";
	return query($query);
}
?>