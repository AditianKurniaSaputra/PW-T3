<?php 
require 'assets/php/functions.php';
$perusahaanMobil = query("SELECT * FROM daftar_mobil");
?>
<!DOCTYPE html>
<html>
<head>
	<title>Halaman Admin</title>
	<style>
		h1 {
			text-align: center;
		}

		.jud {
			background-color: orange;
		}
		.ubah {
			border-radius: 15%;
			height: 20px;
			width: 30px;
			padding: 5px;
			background-color: green;
			color: black;
			text-decoration: none;
		}
		.ubah:hover, .hapus:hover{
			background-color: black;
		}
		.hapus {
			border-radius: 15%;
			height: 20px;
			width: 37px;
			padding: 5px;
			background-color: red;
			color: black;
			text-decoration: none;
		}
		.hapus span:hover, .ubah span:hover{
			color: white;
		}
	</style>
</head>
<body>

<h1>Daftar Mobil terkenal Di Dunia</h1>

<table border="1" cellpadding="10" cellspacing="0">

	<tr class="jud">
		<th>No.</th>
		<th width="125">Aksi</th>
		<th>Gambar</th>
		<th width="100">Merk</th>
		<th width="80">Tahun produksi</th>
		<th width="170">Pendiri</th>
		<th width="120">Harga</th>
	</tr>

	<?php $i = 1; ?>
	<?php foreach( $perusahaanMobil as $row ) : ?>
	<tr>
		<td align="center"><?= $i; ?></td>
		<td>
			<a class="ubah" href=""><span>ubah</span></a> <a class="hapus" href=""><span>hapus</span></a>
		</td>
		<td align="center"><img width="75" src="assets/img/<?= $row['Gambar'] ?>"></td>
		<td><?= $row["Merk"]; ?></td>
		<td><?= $row["Tahun Produksi"]; ?></td>
		<td><?= $row["Pendiri"] ?></td>
		<td><?= $row["Harga"] ?></td>
	</tr>
	<?php $i++; ?>
	<?php endforeach; ?>
	
</table>

</body>
</html>