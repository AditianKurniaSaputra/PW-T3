<?php
require 'functions.php';

// ambil data di URL
$id = $_GET["id"];


$smart = query("SELECT * FROM daftar_mobil WHERE id = $id")[0];


// cek apakah tombol submit sudah ditekan atau belum
if( isset($_POST["submit"]) ) {
	
	// cek apakah data berhasil diubah atau tidak
	if( ubah($_POST) > 0 ) {
		echo "
			<script>
				alert('data berhasil diubah!');
				document.location.href = '../../index.php';
			</script>
		";
	} else {
		echo "
			<script>
				alert('data gagal diubah!');
				document.location.href = '../../index.php';
			</script>
		";
	}


}
?>
<!DOCTYPE html>
<html>
<head>
	<title>Ubah data Mobil</title>
</head>
<body>
	
	<h1>Ubah data Mobil</h1>

	<form action="" method="post">
		<input type="hidden" name="id" value="<?= $cars["id"]; ?>">
		<ul>
			<li>
				<label for="Gambar">Gambar : </label>
				<input type="text" name="Gambar" id="Gambar" required value="<?= $cars["Gambar"]; ?>">
			</li>
			<li>
				<label for="Merk">Merk : </label>
				<input type="text" name="Merk" id="Merk" value="<?= $cars["Merk"]; ?>">
			</li>
			<li>
				<label for="Tahun Produksi">Tahun Produksi :</label>
				<input type="text" name="Tahun Produksi" id="Tahun Produksi" value="<?= $cars["Tahun Produksi"]; ?>">
			</li>
			<li>
				<label for="Pendiri">Pendiri :</label>
				<input type="text" name="Pendiri" id="Pendiri" value="<?= $cars["Pendiri"]; ?>">
			</li>
			<li>
				<label for="Harga">Harga :</label>
				<input type="text" name="Harga" id="Harga" value="<?= $cars["Harga"]; ?>">
			</li>
			
			<li>
				<button type="submit" name="submit">Ubah Data!</button>
			</li>
		</ul>

	</form>

</body>
</html>