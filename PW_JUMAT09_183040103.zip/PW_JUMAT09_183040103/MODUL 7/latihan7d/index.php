<?php 
require 'assets/php/functions.php';
$perusahaanMobil = query("SELECT * FROM daftar_mobil");


?>
<!DOCTYPE html>
<html>
<head>
	<title>Halaman Admin</title>
	<link rel="stylesheet" type="text/css" href="assets/css/me.css">
</head>
<body>

<h1 align="center">Daftar Mobil terkenal di Dunia</h1>

<div align="center"><span class="tambah"><a href="assets/php/tambah.php">Tambah data perusahaan Mobil</a></span></div>
<br><br>



<table border="1" cellpadding="10" cellspacing="0" align="center">

	<tr class="jud">
		<th>No.</th>
		<th width="125">Aksi</th>
		<th>Gambar</th>
		<th width="100">Merk</th>
		<th width="80">Tahun Produksi</th>
		<th width="170">Pendiri</th>
		<th width="120">Harga</th>
	</tr>

	<?php $i = 1; ?>
	<?php foreach( $perusahaanMobil as $row ) : ?>
	<tr>
		<td align="center"><?= $i; ?></td>
		<td>
			<a class="ubah" href="assets/php/ubah.php?id=<?= $row["id"]; ?>"><span>ubah</span></a> <a class="hapus" href="assets/php/hapus.php?id=<?= $row["id"]; ?>"><span>hapus</span></a>
		</td>
		<td align="center"><img width="75" src="assets/img/<?= $row['Gambar'] ?>"></td>
		<td><?= $row["Merk"]; ?></td>
		<td><?= $row["Tahun Produksi"]; ?></td>
		<td><?= $row["Pendiri"] ?></td>
		<td><?= $row["Harga"] ?></td>
	</tr>
	<?php $i++; ?>
	<?php endforeach; ?>
	
</table>

</body>
</html>