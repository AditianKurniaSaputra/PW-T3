<?php 
$conn = mysqli_connect("localhost", "root", "") or die("koneksi ke DB gagal!");
mysqli_select_db($conn, "mobil") or die("Database salah!");
?>

<!DOCTYPE html>
<html>
<head>
	<title>Latihan 6a</title>
	<style>
		.aa {
			background-color: orange;
		}
		.content img{
			width: 100px;
			height: 100px;
		}
	</style>
</head>
<body>
	<?php $a=1; ?>
	<div class="container">
		<?php 
		$result = mysqli_query($conn, "SELECT * FROM daftar_mobil");
		
		?>
		<div class="content">
			<table border="1" cellspacing="0" cellpadding="3">
				<tr align="center" class="aa">
					<td>No</td>
					<td>Gambar</td>
					<td width="110">Merk</td>
					<td width="110">Tahun produksi</td>
					<td>Pendiri</td>
					<td width="135">Harga</td>
				</tr>
					<?php 	while( $row = mysqli_fetch_assoc($result) ){ ?>
				<tr>
					<td align="center"><?= $a++ ?></td>
					<td align="center"><img src="img/<?= $row['Gambar'] ?>"></td>
					<td><?= $row["Merk"]; ?></td>
					<td><?= $row["Tahun Produksi"]; ?></td>
					<td><?= $row["Pendiri"]; ?></td>
					<td><?= $row["Harga"] ?></td>
				</tr>
				<?php } ?>
			</table>
			
		</div>
		
	</div>
</body>
</html>