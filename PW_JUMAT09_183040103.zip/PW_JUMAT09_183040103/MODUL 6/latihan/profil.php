<?php 
// cek apakah tidak ada data di $_GET
if(	!isset($_GET["No"])) {
	// redirect
	header("Location: index.php");
	exit;
}
?>

<!DOCTYPE html>
<html>
<head>
	<title>Profil</title>
	<link rel="stylesheet" type="text/css" href="css..//profil.css">
</head>
<body>
	<div>
		<h1><em>Penjelasan Singkat tentang Mobil Mewah</em></h1>

		<table cellspacing="0" cellpadding="3" align="center">
			<tr align="center">
				<td align="center"><img src="img/<?= $_GET["Gambar"]; ?>"></td>
			</tr>
			<tr align="center">
				<td><?= $_GET["Merk"] ?></td>
			</tr>
			<tr align="center">
				<td><?= $_GET["Tahun_produksi"] ?></td>
			</tr>
			<tr align="center">
				<td><?= $_GET["Pendiri"] ?></td>
			</tr>
			<tr align="center">
				<td><?= $_GET["Harga"] ?></td>
			</tr>
			
		</table>

		<br>

		<a href="index.php">Kembali</a>
	</div>
</body>
</html>