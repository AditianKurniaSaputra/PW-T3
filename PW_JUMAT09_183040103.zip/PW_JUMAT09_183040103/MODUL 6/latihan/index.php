<?php 
	$perusahaanMobil = [
			     [	
			     	"No"	=> "1",
			     	"Gambar" 							=> "lambor2.jpg",
			     	"Merk" 			=> "Lamborghini",
			     	"Tahun_produksi" 					=> "Tahun Pembuatan : 1963",
			     	"Pendiri" 						=> "Pendiri : Ferruccio Lamborghini",
			     	"Harga"					=> " Harga : US$ 97.5 JT",
			     	
			     ],

			     [	
			     	"No"	=> "2",
			     	"Gambar" 							=> "bmw1.jpg",
			     	"Merk" 			=> "BMW",
			     	"Tahun_produksi" 					=> "Tahun Pembuatan : 2004 - 2005",
			     	"Pendiri" 						=> "Pendiri : Franz Josef Popp",
			     	"Harga"					=> " Harga : €76,84 M",
			     	
			     ],

			     [	
			     	"No"	=> "3",
			     	"Gambar" 							=> "ferr.jpg",
			     	"Merk" 			=> "Ferrari",
			     	"Tahun_produksi" 					=> "Tahun Pembuatan : 1947",
			     	"Pendiri" 						=> "Pendiri : Enzo Ferrari",
			     	"Harga"					=> "  Harga : €1,921M",
			     	
			     ],

			     [	
			     	"No"	=> "4",
			     	"Gambar" 							=> "chev.jpg",
			     	"Merk" 			=> "Chevrolet",
			     	"Tahun_produksi" 					=> "Tahun Pembuatan : 1911",
			     	"Pendiri" 						=> "Pendiri : Louis Chevrolet",
			     	"Harga"					=> " Harga : $65,900†",
			     	
			     ],

			     [	
			     	"No"	=> "5",
			     	"Gambar" 							=> "bugatti.jpg",
			     	"Merk" 			=> "Bugatti Automobiles SAS",
			     	"Tahun_produksi" 					=> "Tahun Pembuatan : 1909",
			     	"Pendiri" 						=> "Pendiri : Ettore Bugatti",
			     	"Harga"					=> " Harga : $1,700,000",
			     	
			     ],

			     [	
			     	"No"	=> "6",
			     	"Gambar" 							=> "pagani1.jpg",
			     	"Merk" 			=> "Pagani",
			     	"Tahun_produksi" 					=> "Tahun Pembuatan : 1992",
			     	"Pendiri" 						=> "Pendiri : Horacio Pagani",
			     	"Harga"					=> " Harga : $741,000 ",
			     	
			     ],

			     [	
			     	"No"	=> "7",
			     	"Gambar" 							=> "gils.jpg",
			     	"Merk" 			=> "Koenigsegg",
			     	"Tahun_produksi" 					=> "Tahun Pembuatan : 1994",
			     	"Pendiri" 						=> "Pendiri : Christian von Koenigsegg",
			     	"Harga"					=> " Harga : $600,910 ",
			     	
			     ],

			     [	
			     	"No"	=> "8",
			     	"Gambar" 							=> "por.jpg",
			     	"Merk" 			=> "Porsche",
			     	"Tahun_produksi" 					=> "Tahun Pembuatan : 1931",
			     	"Pendiri" 						=> "Pendiri : Ferdinand Porsche",
			     	"Harga"					=> " Harga : $484,000",
			     	
			     ],

			     [	
			     	"No"	=> "9",
			     	"Gambar" 							=> "marc.jpeg",
			     	"Merk" 			=> "Mercedes-Benz",
			     	"Tahun_produksi" 					=> "Tahun Pembuatan : 1886",
			     	"Pendiri" 						=> "Pendiri : Karl Benz",
			     	"Harga"					=> " Harga : $455,500",
			     	
			     ],

			     [	
			     	"No"	=> "10",
			     	"Gambar" 							=> "may.png",
			     	"Merk" 			=> "Maybach",
			     	"Tahun_produksi" 					=> "Tahun Pembuatan : 1909",
			     	"Pendiri" 						=> "Pendiri : Wilhelm Maybach",
			     	"Harga"					=> " Harga : $385,250",
			     	
			     ]

			 ];
 ?>



<!DOCTYPE html>
<html>
<head>
	<title>Index</title>
	<link rel="stylesheet" type="text/css" href="css../index.css">
</head>
<body>

	<h2>Daftar Mobil terkenal di Dunia 2019</h2>

	<div class="box">
		<ul>
			<?php foreach ($perusahaanMobil as $cars): ?>
			<div  class="a">
				<img width="80" src="img/<?= $cars["Gambar"]; ?>">
	
				<p class="b"><a href="profil.php?No=<?= $cars['No']; ?>&Gambar=<?= $cars['Gambar']; ?>&Merk=<?= $cars['Merk']; ?>&Tahun_produksi=<?= $cars['Tahun_produksi']; ?>&Pendiri=<?= $cars['Pendiri']; ?>&Harga=<?= $cars['Harga']; ?>">
				<?= $cars['Merk']; ?>
				</a></p>

				<p class="c"><?= $cars['Harga'] ?></p>
			</div>
			<?php endforeach; ?>
		</ul>
	</div>

</body>
</html>