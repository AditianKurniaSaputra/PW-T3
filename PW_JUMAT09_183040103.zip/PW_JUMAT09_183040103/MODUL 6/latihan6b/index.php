<!-- <?php 
$conn = mysqli_connect("localhost", "root", "") or die("koneksi ke DB gagal!");
mysqli_select_db($conn, "mobil") or die("Database salah!");
?>  -->

<?php 
require 'php/function.php';
$perusahaanMobil = query("SELECT * FROM daftar_mobil");
?>
<!DOCTYPE html>
<html>
<head>
	<title>Latihan 6b</title>
	<style>
		.aa {
			background-color: orange;
		}
		.content img{
			width: 100px;
			height: 100px;
		}
	</style>
</head>
<body>
	<?php $a=1; ?>
	<div class="container">
		<table border="1" cellspacing="0" cellpadding="3">
				<tr align="center" class="aa">
					<td>No</td>
					<td>Gambar</td>
					<td width="110">Merk</td>
					<td width="110">Tahun produksi</td>
					<td>Pendiri</td>
					<td width="135">Harga</td>
				</tr>
		<?php foreach ($perusahaanMobil as $cars ) : ?>
		<div class="content">
				<tr>
					<td align="center"><?= $a++ ?></td>
					<td align="center"><img src="img/<?= $cars['Gambar'] ?>"></td>
					<td><?= $cars["Merk"]; ?></td>
					<td><?= $cars["Tahun Produksi"]; ?></td>
					<td><?= $cars["Pendiri"]; ?></td>
					<td><?= $cars["Harga"] ?></td>
				</tr>
		</div>
		<?php endforeach; ?>
		</table>
	</div>
</body>
</html>