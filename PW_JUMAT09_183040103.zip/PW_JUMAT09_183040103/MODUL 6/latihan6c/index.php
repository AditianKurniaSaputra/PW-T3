<?php 
require 'php/function.php';
$perusahaanMobil = query("SELECT * FROM daftar_mobil");
?>
<!DOCTYPE html>
<html>
<head>
	<title>Latihan 6c</title>
	<style>
		.container {
			width: 400px;
			height: 500px;
			background-color: rgb(171, 255, 0);
			margin: 50px auto;
			padding: 20px;
			box-shadow: 0 0 10px 10px rgba(0,0,0,.75);
			transition: .3s;
		}
		.container h2, h3 {
			text-align: center;

		}
		.content a {
			color: black;
			text-decoration: none;
		}

		.content a:hover{
			color: white;
		}
		.container:hover {
			box-shadow: inset 0 0 10px 10px rgba(0,0,0,.85);
		}
	</style>
</head>
<body>
	<div class="container">
		<h2>Daftar Mobil Terkenal di Dunia</h2>
		<h3>Merk Mobil</h3>
		<ul>
			<?php foreach ($perusahaanMobil as $cars ) : ?>
			<div class="content">
				<p class="Merk">
					<a href="php/profil.php?id=<?= $cars['id'] ?>"><?= $cars['Merk']; ?></a>
				</p>
			</div>
			<?php endforeach; ?>
		</ul>
	</div>
</body>
</html>